# The League's Amazing Class Tracker

This is a class tracker meant to do stuff. It uses Google's AppEngine framework.
